# teste_Marina
Projeto com o objetivo de criar um software que armazene dados dos produtos e categorias.
